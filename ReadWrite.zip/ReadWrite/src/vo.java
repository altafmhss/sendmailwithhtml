
public class vo {

	 private String BRAND;
	 private String ASSIGNED_BRAND;
	 private String CO_LOC_NAME;
	 private String CO_LOC_DBR10;
	 private String CO_LOC_DBR;
	 private String CO_RENTAL_STATE;
	 private String ACCIDENT_STATE;
	 private String RENTER_STATE;
	 private String COMPANY_CODE;
	 private String CI_LOCATION_NAME;
	 private String CO_DISTRICT;
	 private String CO_ZONE;
	 private String CI_DISTRICT;
	 private String CI_ZONE;
	 private String FLEET_OWNER;
	 private String VEH_MAKE;
	 private String VEH_MODEL;
	 private String MVA;
	 private String VIN;
	 private String ESTIMATE_ID;
	 private String RA_NUMBER;
	 private String CLAIM_NUMBER;
	 private String RENTER_NAME_FULL;
	 private String REVIEWED_YN;
	 private String DOB;
	 private String RECOVERY_STATUS;
	 private String RECOVERY_CLOSE_CODE;
	 private String RENTAL_DATE;
	 private String SYSTEM_ENTRY_DATE;
	 private String DATE_OF_LOSS;
	 private String REPORT_DATE;
	 private String REPORT_MOYR;
	 private String LOSS_TYPE;
	 private String SED_RUC;
	 private String TCOR_TOTAL;
	 private String EST_TOTAL;
	 private String EST_DIMVAL;
	 private String EST_LOU;
	 private String EST_STORAGE_TOW;
	 private String EST_ADMIN;
	 private String REVIEW_DATE;
	 private String MAX_BILLED_TOTAL;
	 private String MAX_BILLED_SED_TOTAL;
	 private String CONVERT_BILLED_AMT;
	 private String CONVERT_OPEN_MAXBILLED;
	 private String CONVERT_CLOSED_MAXBILLED;
	 private String VIK_BILLED_AMT;
	 private String VIK_REBILLING;
	 private String SEDWICK_BILLED_TOTAL;
	 private String VIKING_BILLED_TOTAL;
	 private String DAMAGE_AMOUNT;
	 private String LOSS_OF_USE_AMOUNT;
	 private String ADMIN_FEE_AMOUNT;
	 private String DIMVAL_AMOUNT;
	 private String STORAGE_TOW_AMOUNT;
	 private String RECOVERED_AMT_GROSS;
	 private String PAYMENTS;
	 private String RECOVERED_AMT_ADJUSTED;
	 private String NON_CASH_SUBRO_RECOVERY;
	 private String VIK_RECOVERY_TOTAL;
	 private String VIK_COLLECTION_RECOVERY;
	 private String VIK_BILLING_RECOVERY;
	 private String CONVERT_RECOVERED_AMT;
	 private String CONVERT_CLOSED_RECOVERY;
	 private String CONVERT_PENDING_RECOVERY;
	 private String WRITEOFF_TOTAL;
	 private String CONVERT_WRITEOFF_TOTAL;
	 private String OUTSTANDING_TOTAL;
	 private String COMMISSION_COSTS;
	 private String BILLING_COMMISSION;
	 private String COLLECTION_COMMISSION;
	 private String CREDIT_CARD_COST;
	 private String VIK_COMMISION;
	 private String COMMISSION_REIMBURSEMENT;
	 private String CONVERT_COMMISSION_COST;
	 private String OTHER_COLLECTION_COST;
	 private String CONVERT_OTHER_COLLECT_COST;
	 private String CURRENT_BILLINGS;
	 private String PRIOR_TO_MAY_ADJ;
	 private String ESV_ADJUSTMENT_AMT;
	 private String OTHER_REDUCTIONS;
	 private String BILLED_DATE;
	 private String BILLED_MOYR;
	 private String ESUB_IND;
	 private String ESUB_DATE;
	 private String NEGOTIATED_AMT;
	 private String NEGOTIATED_DATE;
	 private String NEGOTIATED_MOYR;
	 private String RECOVERED_AMT_NET;
	 private String DAMAGE_AMOUNT_COLLECTED;
	 private String LOU_COLLECTED;
	 private String ADMIN_COLLECTED;
	 private String DIMVAL_COLLECTED;
	 private String STORAGE_TOW_COLLECTED;
	 private String RECOVERY_EXPENSE_WCOM;
	 private String RECOVERED_IND;
	 private String FIRST_RECOVERY_DATE;
	 private String LAST_RECOVERY_DATE;
	 private String LAST_RECOVERY_MOYR;
	 private String INSTALLMENT_IND;
	 private String DUPLICATE_TYPE;
	 private String UNALLOCATED_IND;
	 private String LDW_CDW_IND;
	 private String CORPORATE_COVERAGE;
	 private String FREE_CDW_IND;
	 private String CDW_WITH_DEDUCTIBLE_IND;
	 private String CDW_DEDUCTIBLE_AMT;
	 private String AWDBCD_PARENT_NAME;
	 private String AWDBCD_DIV_NAME;
	 private String AWDBCD_PARENT;
	 private String AWDBCD_DIV;
	 private String RECOVERY_REP_NAME;
	 private String AGENCY_ATTORNEY;
	 private String ASSIGNED_IND;
	 private String ZIP_RECOVERY_LETTER;
	 private String LIABILITY_IND;
	 private String VIK_IND;
	 private String LAST_LETTER_NAME;
	 private String LAST_LETTER_DATE;
	 private String DAYS_TO_BILL;
	 private String ZIP_MEMBER_ID;
	 private String ZIP_FLEET_ID;
	 private String RECOVERY_CLOSE_DATE;
	 private String ZIP_NUMBER;
	 private String RUN_DATE;
	 private String LOSS_CAUSATION;
	 private String SENT_DATE;
	 private String RECOVERY_STATUS_DESC;
	 private String Lyft_Period_Initial;
	 private String Lyft_Period_current;
	 private String Lyft_Date_Initial;
	 private String Lyft_Date_Current;
	 private String Location_Mnemonic;
	 private String Ride_hailing_id;
	public String getBRAND() {
		return BRAND;
	}
	public void setBRAND(String bRAND) {
		BRAND = bRAND;
	}
	public String getASSIGNED_BRAND() {
		return ASSIGNED_BRAND;
	}
	public void setASSIGNED_BRAND(String aSSIGNED_BRAND) {
		ASSIGNED_BRAND = aSSIGNED_BRAND;
	}
	public String getCO_LOC_NAME() {
		return CO_LOC_NAME;
	}
	public void setCO_LOC_NAME(String cO_LOC_NAME) {
		CO_LOC_NAME = cO_LOC_NAME;
	}
	public String getCO_LOC_DBR10() {
		return CO_LOC_DBR10;
	}
	public void setCO_LOC_DBR10(String cO_LOC_DBR10) {
		CO_LOC_DBR10 = cO_LOC_DBR10;
	}
	public String getCO_LOC_DBR() {
		return CO_LOC_DBR;
	}
	public void setCO_LOC_DBR(String cO_LOC_DBR) {
		CO_LOC_DBR = cO_LOC_DBR;
	}
	public String getCO_RENTAL_STATE() {
		return CO_RENTAL_STATE;
	}
	public void setCO_RENTAL_STATE(String cO_RENTAL_STATE) {
		CO_RENTAL_STATE = cO_RENTAL_STATE;
	}
	public String getACCIDENT_STATE() {
		return ACCIDENT_STATE;
	}
	public void setACCIDENT_STATE(String aCCIDENT_STATE) {
		ACCIDENT_STATE = aCCIDENT_STATE;
	}
	public String getRENTER_STATE() {
		return RENTER_STATE;
	}
	public void setRENTER_STATE(String rENTER_STATE) {
		RENTER_STATE = rENTER_STATE;
	}
	public String getCOMPANY_CODE() {
		return COMPANY_CODE;
	}
	public void setCOMPANY_CODE(String cOMPANY_CODE) {
		COMPANY_CODE = cOMPANY_CODE;
	}
	public String getCI_LOCATION_NAME() {
		return CI_LOCATION_NAME;
	}
	public void setCI_LOCATION_NAME(String cI_LOCATION_NAME) {
		CI_LOCATION_NAME = cI_LOCATION_NAME;
	}
	public String getCO_DISTRICT() {
		return CO_DISTRICT;
	}
	public void setCO_DISTRICT(String cO_DISTRICT) {
		CO_DISTRICT = cO_DISTRICT;
	}
	public String getCO_ZONE() {
		return CO_ZONE;
	}
	public void setCO_ZONE(String cO_ZONE) {
		CO_ZONE = cO_ZONE;
	}
	public String getCI_DISTRICT() {
		return CI_DISTRICT;
	}
	public void setCI_DISTRICT(String cI_DISTRICT) {
		CI_DISTRICT = cI_DISTRICT;
	}
	public String getCI_ZONE() {
		return CI_ZONE;
	}
	public void setCI_ZONE(String cI_ZONE) {
		CI_ZONE = cI_ZONE;
	}
	public String getFLEET_OWNER() {
		return FLEET_OWNER;
	}
	public void setFLEET_OWNER(String fLEET_OWNER) {
		FLEET_OWNER = fLEET_OWNER;
	}
	public String getVEH_MAKE() {
		return VEH_MAKE;
	}
	public void setVEH_MAKE(String vEH_MAKE) {
		VEH_MAKE = vEH_MAKE;
	}
	public String getVEH_MODEL() {
		return VEH_MODEL;
	}
	public void setVEH_MODEL(String vEH_MODEL) {
		VEH_MODEL = vEH_MODEL;
	}
	public String getMVA() {
		return MVA;
	}
	public void setMVA(String mVA) {
		MVA = mVA;
	}
	public String getVIN() {
		return VIN;
	}
	public void setVIN(String vIN) {
		VIN = vIN;
	}
	public String getESTIMATE_ID() {
		return ESTIMATE_ID;
	}
	public void setESTIMATE_ID(String eSTIMATE_ID) {
		ESTIMATE_ID = eSTIMATE_ID;
	}
	public String getRA_NUMBER() {
		return RA_NUMBER;
	}
	public void setRA_NUMBER(String rA_NUMBER) {
		RA_NUMBER = rA_NUMBER;
	}
	public String getCLAIM_NUMBER() {
		return CLAIM_NUMBER;
	}
	public void setCLAIM_NUMBER(String cLAIM_NUMBER) {
		CLAIM_NUMBER = cLAIM_NUMBER;
	}
	public String getRENTER_NAME_FULL() {
		return RENTER_NAME_FULL;
	}
	public void setRENTER_NAME_FULL(String rENTER_NAME_FULL) {
		RENTER_NAME_FULL = rENTER_NAME_FULL;
	}
	public String getREVIEWED_YN() {
		return REVIEWED_YN;
	}
	public void setREVIEWED_YN(String rEVIEWED_YN) {
		REVIEWED_YN = rEVIEWED_YN;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getRECOVERY_STATUS() {
		return RECOVERY_STATUS;
	}
	public void setRECOVERY_STATUS(String rECOVERY_STATUS) {
		RECOVERY_STATUS = rECOVERY_STATUS;
	}
	public String getRECOVERY_CLOSE_CODE() {
		return RECOVERY_CLOSE_CODE;
	}
	public void setRECOVERY_CLOSE_CODE(String rECOVERY_CLOSE_CODE) {
		RECOVERY_CLOSE_CODE = rECOVERY_CLOSE_CODE;
	}
	public String getRENTAL_DATE() {
		return RENTAL_DATE;
	}
	public void setRENTAL_DATE(String rENTAL_DATE) {
		RENTAL_DATE = rENTAL_DATE;
	}
	public String getSYSTEM_ENTRY_DATE() {
		return SYSTEM_ENTRY_DATE;
	}
	public void setSYSTEM_ENTRY_DATE(String sYSTEM_ENTRY_DATE) {
		SYSTEM_ENTRY_DATE = sYSTEM_ENTRY_DATE;
	}
	public String getDATE_OF_LOSS() {
		return DATE_OF_LOSS;
	}
	public void setDATE_OF_LOSS(String dATE_OF_LOSS) {
		DATE_OF_LOSS = dATE_OF_LOSS;
	}
	public String getREPORT_DATE() {
		return REPORT_DATE;
	}
	public void setREPORT_DATE(String rEPORT_DATE) {
		REPORT_DATE = rEPORT_DATE;
	}
	public String getREPORT_MOYR() {
		return REPORT_MOYR;
	}
	public void setREPORT_MOYR(String rEPORT_MOYR) {
		REPORT_MOYR = rEPORT_MOYR;
	}
	public String getLOSS_TYPE() {
		return LOSS_TYPE;
	}
	public void setLOSS_TYPE(String lOSS_TYPE) {
		LOSS_TYPE = lOSS_TYPE;
	}
	public String getSED_RUC() {
		return SED_RUC;
	}
	public void setSED_RUC(String sED_RUC) {
		SED_RUC = sED_RUC;
	}
	public String getTCOR_TOTAL() {
		return TCOR_TOTAL;
	}
	public void setTCOR_TOTAL(String tCOR_TOTAL) {
		TCOR_TOTAL = tCOR_TOTAL;
	}
	public String getEST_TOTAL() {
		return EST_TOTAL;
	}
	public void setEST_TOTAL(String eST_TOTAL) {
		EST_TOTAL = eST_TOTAL;
	}
	public String getEST_DIMVAL() {
		return EST_DIMVAL;
	}
	public void setEST_DIMVAL(String eST_DIMVAL) {
		EST_DIMVAL = eST_DIMVAL;
	}
	public String getEST_LOU() {
		return EST_LOU;
	}
	public void setEST_LOU(String eST_LOU) {
		EST_LOU = eST_LOU;
	}
	public String getEST_STORAGE_TOW() {
		return EST_STORAGE_TOW;
	}
	public void setEST_STORAGE_TOW(String eST_STORAGE_TOW) {
		EST_STORAGE_TOW = eST_STORAGE_TOW;
	}
	public String getEST_ADMIN() {
		return EST_ADMIN;
	}
	public void setEST_ADMIN(String eST_ADMIN) {
		EST_ADMIN = eST_ADMIN;
	}
	public String getREVIEW_DATE() {
		return REVIEW_DATE;
	}
	public void setREVIEW_DATE(String rEVIEW_DATE) {
		REVIEW_DATE = rEVIEW_DATE;
	}
	public String getMAX_BILLED_TOTAL() {
		return MAX_BILLED_TOTAL;
	}
	public void setMAX_BILLED_TOTAL(String mAX_BILLED_TOTAL) {
		MAX_BILLED_TOTAL = mAX_BILLED_TOTAL;
	}
	public String getMAX_BILLED_SED_TOTAL() {
		return MAX_BILLED_SED_TOTAL;
	}
	public void setMAX_BILLED_SED_TOTAL(String mAX_BILLED_SED_TOTAL) {
		MAX_BILLED_SED_TOTAL = mAX_BILLED_SED_TOTAL;
	}
	public String getCONVERT_BILLED_AMT() {
		return CONVERT_BILLED_AMT;
	}
	public void setCONVERT_BILLED_AMT(String cONVERT_BILLED_AMT) {
		CONVERT_BILLED_AMT = cONVERT_BILLED_AMT;
	}
	public String getCONVERT_OPEN_MAXBILLED() {
		return CONVERT_OPEN_MAXBILLED;
	}
	public void setCONVERT_OPEN_MAXBILLED(String cONVERT_OPEN_MAXBILLED) {
		CONVERT_OPEN_MAXBILLED = cONVERT_OPEN_MAXBILLED;
	}
	public String getCONVERT_CLOSED_MAXBILLED() {
		return CONVERT_CLOSED_MAXBILLED;
	}
	public void setCONVERT_CLOSED_MAXBILLED(String cONVERT_CLOSED_MAXBILLED) {
		CONVERT_CLOSED_MAXBILLED = cONVERT_CLOSED_MAXBILLED;
	}
	public String getVIK_BILLED_AMT() {
		return VIK_BILLED_AMT;
	}
	public void setVIK_BILLED_AMT(String vIK_BILLED_AMT) {
		VIK_BILLED_AMT = vIK_BILLED_AMT;
	}
	public String getVIK_REBILLING() {
		return VIK_REBILLING;
	}
	public void setVIK_REBILLING(String vIK_REBILLING) {
		VIK_REBILLING = vIK_REBILLING;
	}
	public String getSEDWICK_BILLED_TOTAL() {
		return SEDWICK_BILLED_TOTAL;
	}
	public void setSEDWICK_BILLED_TOTAL(String sEDWICK_BILLED_TOTAL) {
		SEDWICK_BILLED_TOTAL = sEDWICK_BILLED_TOTAL;
	}
	public String getVIKING_BILLED_TOTAL() {
		return VIKING_BILLED_TOTAL;
	}
	public void setVIKING_BILLED_TOTAL(String vIKING_BILLED_TOTAL) {
		VIKING_BILLED_TOTAL = vIKING_BILLED_TOTAL;
	}
	public String getDAMAGE_AMOUNT() {
		return DAMAGE_AMOUNT;
	}
	public void setDAMAGE_AMOUNT(String dAMAGE_AMOUNT) {
		DAMAGE_AMOUNT = dAMAGE_AMOUNT;
	}
	public String getLOSS_OF_USE_AMOUNT() {
		return LOSS_OF_USE_AMOUNT;
	}
	public void setLOSS_OF_USE_AMOUNT(String lOSS_OF_USE_AMOUNT) {
		LOSS_OF_USE_AMOUNT = lOSS_OF_USE_AMOUNT;
	}
	public String getADMIN_FEE_AMOUNT() {
		return ADMIN_FEE_AMOUNT;
	}
	public void setADMIN_FEE_AMOUNT(String aDMIN_FEE_AMOUNT) {
		ADMIN_FEE_AMOUNT = aDMIN_FEE_AMOUNT;
	}
	public String getDIMVAL_AMOUNT() {
		return DIMVAL_AMOUNT;
	}
	public void setDIMVAL_AMOUNT(String dIMVAL_AMOUNT) {
		DIMVAL_AMOUNT = dIMVAL_AMOUNT;
	}
	public String getSTORAGE_TOW_AMOUNT() {
		return STORAGE_TOW_AMOUNT;
	}
	public void setSTORAGE_TOW_AMOUNT(String sTORAGE_TOW_AMOUNT) {
		STORAGE_TOW_AMOUNT = sTORAGE_TOW_AMOUNT;
	}
	public String getRECOVERED_AMT_GROSS() {
		return RECOVERED_AMT_GROSS;
	}
	public void setRECOVERED_AMT_GROSS(String rECOVERED_AMT_GROSS) {
		RECOVERED_AMT_GROSS = rECOVERED_AMT_GROSS;
	}
	public String getPAYMENTS() {
		return PAYMENTS;
	}
	public void setPAYMENTS(String pAYMENTS) {
		PAYMENTS = pAYMENTS;
	}
	public String getRECOVERED_AMT_ADJUSTED() {
		return RECOVERED_AMT_ADJUSTED;
	}
	public void setRECOVERED_AMT_ADJUSTED(String rECOVERED_AMT_ADJUSTED) {
		RECOVERED_AMT_ADJUSTED = rECOVERED_AMT_ADJUSTED;
	}
	public String getNON_CASH_SUBRO_RECOVERY() {
		return NON_CASH_SUBRO_RECOVERY;
	}
	public void setNON_CASH_SUBRO_RECOVERY(String nON_CASH_SUBRO_RECOVERY) {
		NON_CASH_SUBRO_RECOVERY = nON_CASH_SUBRO_RECOVERY;
	}
	public String getVIK_RECOVERY_TOTAL() {
		return VIK_RECOVERY_TOTAL;
	}
	public void setVIK_RECOVERY_TOTAL(String vIK_RECOVERY_TOTAL) {
		VIK_RECOVERY_TOTAL = vIK_RECOVERY_TOTAL;
	}
	public String getVIK_COLLECTION_RECOVERY() {
		return VIK_COLLECTION_RECOVERY;
	}
	public void setVIK_COLLECTION_RECOVERY(String vIK_COLLECTION_RECOVERY) {
		VIK_COLLECTION_RECOVERY = vIK_COLLECTION_RECOVERY;
	}
	public String getVIK_BILLING_RECOVERY() {
		return VIK_BILLING_RECOVERY;
	}
	public void setVIK_BILLING_RECOVERY(String vIK_BILLING_RECOVERY) {
		VIK_BILLING_RECOVERY = vIK_BILLING_RECOVERY;
	}
	public String getCONVERT_RECOVERED_AMT() {
		return CONVERT_RECOVERED_AMT;
	}
	public void setCONVERT_RECOVERED_AMT(String cONVERT_RECOVERED_AMT) {
		CONVERT_RECOVERED_AMT = cONVERT_RECOVERED_AMT;
	}
	public String getCONVERT_CLOSED_RECOVERY() {
		return CONVERT_CLOSED_RECOVERY;
	}
	public void setCONVERT_CLOSED_RECOVERY(String cONVERT_CLOSED_RECOVERY) {
		CONVERT_CLOSED_RECOVERY = cONVERT_CLOSED_RECOVERY;
	}
	public String getCONVERT_PENDING_RECOVERY() {
		return CONVERT_PENDING_RECOVERY;
	}
	public void setCONVERT_PENDING_RECOVERY(String cONVERT_PENDING_RECOVERY) {
		CONVERT_PENDING_RECOVERY = cONVERT_PENDING_RECOVERY;
	}
	public String getWRITEOFF_TOTAL() {
		return WRITEOFF_TOTAL;
	}
	public void setWRITEOFF_TOTAL(String wRITEOFF_TOTAL) {
		WRITEOFF_TOTAL = wRITEOFF_TOTAL;
	}
	public String getCONVERT_WRITEOFF_TOTAL() {
		return CONVERT_WRITEOFF_TOTAL;
	}
	public void setCONVERT_WRITEOFF_TOTAL(String cONVERT_WRITEOFF_TOTAL) {
		CONVERT_WRITEOFF_TOTAL = cONVERT_WRITEOFF_TOTAL;
	}
	public String getOUTSTANDING_TOTAL() {
		return OUTSTANDING_TOTAL;
	}
	public void setOUTSTANDING_TOTAL(String oUTSTANDING_TOTAL) {
		OUTSTANDING_TOTAL = oUTSTANDING_TOTAL;
	}
	public String getCOMMISSION_COSTS() {
		return COMMISSION_COSTS;
	}
	public void setCOMMISSION_COSTS(String cOMMISSION_COSTS) {
		COMMISSION_COSTS = cOMMISSION_COSTS;
	}
	public String getBILLING_COMMISSION() {
		return BILLING_COMMISSION;
	}
	public void setBILLING_COMMISSION(String bILLING_COMMISSION) {
		BILLING_COMMISSION = bILLING_COMMISSION;
	}
	public String getCOLLECTION_COMMISSION() {
		return COLLECTION_COMMISSION;
	}
	public void setCOLLECTION_COMMISSION(String cOLLECTION_COMMISSION) {
		COLLECTION_COMMISSION = cOLLECTION_COMMISSION;
	}
	public String getCREDIT_CARD_COST() {
		return CREDIT_CARD_COST;
	}
	public void setCREDIT_CARD_COST(String cREDIT_CARD_COST) {
		CREDIT_CARD_COST = cREDIT_CARD_COST;
	}
	public String getVIK_COMMISION() {
		return VIK_COMMISION;
	}
	public void setVIK_COMMISION(String vIK_COMMISION) {
		VIK_COMMISION = vIK_COMMISION;
	}
	public String getCOMMISSION_REIMBURSEMENT() {
		return COMMISSION_REIMBURSEMENT;
	}
	public void setCOMMISSION_REIMBURSEMENT(String cOMMISSION_REIMBURSEMENT) {
		COMMISSION_REIMBURSEMENT = cOMMISSION_REIMBURSEMENT;
	}
	public String getCONVERT_COMMISSION_COST() {
		return CONVERT_COMMISSION_COST;
	}
	public void setCONVERT_COMMISSION_COST(String cONVERT_COMMISSION_COST) {
		CONVERT_COMMISSION_COST = cONVERT_COMMISSION_COST;
	}
	public String getOTHER_COLLECTION_COST() {
		return OTHER_COLLECTION_COST;
	}
	public void setOTHER_COLLECTION_COST(String oTHER_COLLECTION_COST) {
		OTHER_COLLECTION_COST = oTHER_COLLECTION_COST;
	}
	public String getCONVERT_OTHER_COLLECT_COST() {
		return CONVERT_OTHER_COLLECT_COST;
	}
	public void setCONVERT_OTHER_COLLECT_COST(String cONVERT_OTHER_COLLECT_COST) {
		CONVERT_OTHER_COLLECT_COST = cONVERT_OTHER_COLLECT_COST;
	}
	public String getCURRENT_BILLINGS() {
		return CURRENT_BILLINGS;
	}
	public void setCURRENT_BILLINGS(String cURRENT_BILLINGS) {
		CURRENT_BILLINGS = cURRENT_BILLINGS;
	}
	public String getPRIOR_TO_MAY_ADJ() {
		return PRIOR_TO_MAY_ADJ;
	}
	public void setPRIOR_TO_MAY_ADJ(String pRIOR_TO_MAY_ADJ) {
		PRIOR_TO_MAY_ADJ = pRIOR_TO_MAY_ADJ;
	}
	public String getESV_ADJUSTMENT_AMT() {
		return ESV_ADJUSTMENT_AMT;
	}
	public void setESV_ADJUSTMENT_AMT(String eSV_ADJUSTMENT_AMT) {
		ESV_ADJUSTMENT_AMT = eSV_ADJUSTMENT_AMT;
	}
	public String getOTHER_REDUCTIONS() {
		return OTHER_REDUCTIONS;
	}
	public void setOTHER_REDUCTIONS(String oTHER_REDUCTIONS) {
		OTHER_REDUCTIONS = oTHER_REDUCTIONS;
	}
	public String getBILLED_DATE() {
		return BILLED_DATE;
	}
	public void setBILLED_DATE(String bILLED_DATE) {
		BILLED_DATE = bILLED_DATE;
	}
	public String getBILLED_MOYR() {
		return BILLED_MOYR;
	}
	public void setBILLED_MOYR(String bILLED_MOYR) {
		BILLED_MOYR = bILLED_MOYR;
	}
	public String getESUB_IND() {
		return ESUB_IND;
	}
	public void setESUB_IND(String eSUB_IND) {
		ESUB_IND = eSUB_IND;
	}
	public String getESUB_DATE() {
		return ESUB_DATE;
	}
	public void setESUB_DATE(String eSUB_DATE) {
		ESUB_DATE = eSUB_DATE;
	}
	public String getNEGOTIATED_AMT() {
		return NEGOTIATED_AMT;
	}
	public void setNEGOTIATED_AMT(String nEGOTIATED_AMT) {
		NEGOTIATED_AMT = nEGOTIATED_AMT;
	}
	public String getNEGOTIATED_DATE() {
		return NEGOTIATED_DATE;
	}
	public void setNEGOTIATED_DATE(String nEGOTIATED_DATE) {
		NEGOTIATED_DATE = nEGOTIATED_DATE;
	}
	public String getNEGOTIATED_MOYR() {
		return NEGOTIATED_MOYR;
	}
	public void setNEGOTIATED_MOYR(String nEGOTIATED_MOYR) {
		NEGOTIATED_MOYR = nEGOTIATED_MOYR;
	}
	public String getRECOVERED_AMT_NET() {
		return RECOVERED_AMT_NET;
	}
	public void setRECOVERED_AMT_NET(String rECOVERED_AMT_NET) {
		RECOVERED_AMT_NET = rECOVERED_AMT_NET;
	}
	public String getDAMAGE_AMOUNT_COLLECTED() {
		return DAMAGE_AMOUNT_COLLECTED;
	}
	public void setDAMAGE_AMOUNT_COLLECTED(String dAMAGE_AMOUNT_COLLECTED) {
		DAMAGE_AMOUNT_COLLECTED = dAMAGE_AMOUNT_COLLECTED;
	}
	public String getLOU_COLLECTED() {
		return LOU_COLLECTED;
	}
	public void setLOU_COLLECTED(String lOU_COLLECTED) {
		LOU_COLLECTED = lOU_COLLECTED;
	}
	public String getADMIN_COLLECTED() {
		return ADMIN_COLLECTED;
	}
	public void setADMIN_COLLECTED(String aDMIN_COLLECTED) {
		ADMIN_COLLECTED = aDMIN_COLLECTED;
	}
	public String getDIMVAL_COLLECTED() {
		return DIMVAL_COLLECTED;
	}
	public void setDIMVAL_COLLECTED(String dIMVAL_COLLECTED) {
		DIMVAL_COLLECTED = dIMVAL_COLLECTED;
	}
	public String getSTORAGE_TOW_COLLECTED() {
		return STORAGE_TOW_COLLECTED;
	}
	public void setSTORAGE_TOW_COLLECTED(String sTORAGE_TOW_COLLECTED) {
		STORAGE_TOW_COLLECTED = sTORAGE_TOW_COLLECTED;
	}
	public String getRECOVERY_EXPENSE_WCOM() {
		return RECOVERY_EXPENSE_WCOM;
	}
	public void setRECOVERY_EXPENSE_WCOM(String rECOVERY_EXPENSE_WCOM) {
		RECOVERY_EXPENSE_WCOM = rECOVERY_EXPENSE_WCOM;
	}
	public String getRECOVERED_IND() {
		return RECOVERED_IND;
	}
	public void setRECOVERED_IND(String rECOVERED_IND) {
		RECOVERED_IND = rECOVERED_IND;
	}
	public String getFIRST_RECOVERY_DATE() {
		return FIRST_RECOVERY_DATE;
	}
	public void setFIRST_RECOVERY_DATE(String fIRST_RECOVERY_DATE) {
		FIRST_RECOVERY_DATE = fIRST_RECOVERY_DATE;
	}
	public String getLAST_RECOVERY_DATE() {
		return LAST_RECOVERY_DATE;
	}
	public void setLAST_RECOVERY_DATE(String lAST_RECOVERY_DATE) {
		LAST_RECOVERY_DATE = lAST_RECOVERY_DATE;
	}
	public String getLAST_RECOVERY_MOYR() {
		return LAST_RECOVERY_MOYR;
	}
	public void setLAST_RECOVERY_MOYR(String lAST_RECOVERY_MOYR) {
		LAST_RECOVERY_MOYR = lAST_RECOVERY_MOYR;
	}
	public String getINSTALLMENT_IND() {
		return INSTALLMENT_IND;
	}
	public void setINSTALLMENT_IND(String iNSTALLMENT_IND) {
		INSTALLMENT_IND = iNSTALLMENT_IND;
	}
	public String getDUPLICATE_TYPE() {
		return DUPLICATE_TYPE;
	}
	public void setDUPLICATE_TYPE(String dUPLICATE_TYPE) {
		DUPLICATE_TYPE = dUPLICATE_TYPE;
	}
	public String getUNALLOCATED_IND() {
		return UNALLOCATED_IND;
	}
	public void setUNALLOCATED_IND(String uNALLOCATED_IND) {
		UNALLOCATED_IND = uNALLOCATED_IND;
	}
	public String getLDW_CDW_IND() {
		return LDW_CDW_IND;
	}
	public void setLDW_CDW_IND(String lDW_CDW_IND) {
		LDW_CDW_IND = lDW_CDW_IND;
	}
	public String getCORPORATE_COVERAGE() {
		return CORPORATE_COVERAGE;
	}
	public void setCORPORATE_COVERAGE(String cORPORATE_COVERAGE) {
		CORPORATE_COVERAGE = cORPORATE_COVERAGE;
	}
	public String getFREE_CDW_IND() {
		return FREE_CDW_IND;
	}
	public void setFREE_CDW_IND(String fREE_CDW_IND) {
		FREE_CDW_IND = fREE_CDW_IND;
	}
	public String getCDW_WITH_DEDUCTIBLE_IND() {
		return CDW_WITH_DEDUCTIBLE_IND;
	}
	public void setCDW_WITH_DEDUCTIBLE_IND(String cDW_WITH_DEDUCTIBLE_IND) {
		CDW_WITH_DEDUCTIBLE_IND = cDW_WITH_DEDUCTIBLE_IND;
	}
	public String getCDW_DEDUCTIBLE_AMT() {
		return CDW_DEDUCTIBLE_AMT;
	}
	public void setCDW_DEDUCTIBLE_AMT(String cDW_DEDUCTIBLE_AMT) {
		CDW_DEDUCTIBLE_AMT = cDW_DEDUCTIBLE_AMT;
	}
	public String getAWDBCD_PARENT_NAME() {
		return AWDBCD_PARENT_NAME;
	}
	public void setAWDBCD_PARENT_NAME(String aWDBCD_PARENT_NAME) {
		AWDBCD_PARENT_NAME = aWDBCD_PARENT_NAME;
	}
	public String getAWDBCD_DIV_NAME() {
		return AWDBCD_DIV_NAME;
	}
	public void setAWDBCD_DIV_NAME(String aWDBCD_DIV_NAME) {
		AWDBCD_DIV_NAME = aWDBCD_DIV_NAME;
	}
	public String getAWDBCD_PARENT() {
		return AWDBCD_PARENT;
	}
	public void setAWDBCD_PARENT(String aWDBCD_PARENT) {
		AWDBCD_PARENT = aWDBCD_PARENT;
	}
	public String getAWDBCD_DIV() {
		return AWDBCD_DIV;
	}
	public void setAWDBCD_DIV(String aWDBCD_DIV) {
		AWDBCD_DIV = aWDBCD_DIV;
	}
	public String getRECOVERY_REP_NAME() {
		return RECOVERY_REP_NAME;
	}
	public void setRECOVERY_REP_NAME(String rECOVERY_REP_NAME) {
		RECOVERY_REP_NAME = rECOVERY_REP_NAME;
	}
	public String getAGENCY_ATTORNEY() {
		return AGENCY_ATTORNEY;
	}
	public void setAGENCY_ATTORNEY(String aGENCY_ATTORNEY) {
		AGENCY_ATTORNEY = aGENCY_ATTORNEY;
	}
	public String getASSIGNED_IND() {
		return ASSIGNED_IND;
	}
	public void setASSIGNED_IND(String aSSIGNED_IND) {
		ASSIGNED_IND = aSSIGNED_IND;
	}
	public String getZIP_RECOVERY_LETTER() {
		return ZIP_RECOVERY_LETTER;
	}
	public void setZIP_RECOVERY_LETTER(String zIP_RECOVERY_LETTER) {
		ZIP_RECOVERY_LETTER = zIP_RECOVERY_LETTER;
	}
	public String getLIABILITY_IND() {
		return LIABILITY_IND;
	}
	public void setLIABILITY_IND(String lIABILITY_IND) {
		LIABILITY_IND = lIABILITY_IND;
	}
	public String getVIK_IND() {
		return VIK_IND;
	}
	public void setVIK_IND(String vIK_IND) {
		VIK_IND = vIK_IND;
	}
	public String getLAST_LETTER_NAME() {
		return LAST_LETTER_NAME;
	}
	public void setLAST_LETTER_NAME(String lAST_LETTER_NAME) {
		LAST_LETTER_NAME = lAST_LETTER_NAME;
	}
	public String getLAST_LETTER_DATE() {
		return LAST_LETTER_DATE;
	}
	public void setLAST_LETTER_DATE(String lAST_LETTER_DATE) {
		LAST_LETTER_DATE = lAST_LETTER_DATE;
	}
	public String getDAYS_TO_BILL() {
		return DAYS_TO_BILL;
	}
	public void setDAYS_TO_BILL(String dAYS_TO_BILL) {
		DAYS_TO_BILL = dAYS_TO_BILL;
	}
	public String getZIP_MEMBER_ID() {
		return ZIP_MEMBER_ID;
	}
	public void setZIP_MEMBER_ID(String zIP_MEMBER_ID) {
		ZIP_MEMBER_ID = zIP_MEMBER_ID;
	}
	public String getZIP_FLEET_ID() {
		return ZIP_FLEET_ID;
	}
	public void setZIP_FLEET_ID(String zIP_FLEET_ID) {
		ZIP_FLEET_ID = zIP_FLEET_ID;
	}
	public String getRECOVERY_CLOSE_DATE() {
		return RECOVERY_CLOSE_DATE;
	}
	public void setRECOVERY_CLOSE_DATE(String rECOVERY_CLOSE_DATE) {
		RECOVERY_CLOSE_DATE = rECOVERY_CLOSE_DATE;
	}
	public String getZIP_NUMBER() {
		return ZIP_NUMBER;
	}
	public void setZIP_NUMBER(String zIP_NUMBER) {
		ZIP_NUMBER = zIP_NUMBER;
	}
	public String getRUN_DATE() {
		return RUN_DATE;
	}
	public void setRUN_DATE(String rUN_DATE) {
		RUN_DATE = rUN_DATE;
	}
	public String getLOSS_CAUSATION() {
		return LOSS_CAUSATION;
	}
	public void setLOSS_CAUSATION(String lOSS_CAUSATION) {
		LOSS_CAUSATION = lOSS_CAUSATION;
	}
	public String getSENT_DATE() {
		return SENT_DATE;
	}
	public void setSENT_DATE(String sENT_DATE) {
		SENT_DATE = sENT_DATE;
	}
	public String getRECOVERY_STATUS_DESC() {
		return RECOVERY_STATUS_DESC;
	}
	public void setRECOVERY_STATUS_DESC(String rECOVERY_STATUS_DESC) {
		RECOVERY_STATUS_DESC = rECOVERY_STATUS_DESC;
	}
	public String getLyft_Period_Initial() {
		return Lyft_Period_Initial;
	}
	public void setLyft_Period_Initial(String lyft_Period_Initial) {
		Lyft_Period_Initial = lyft_Period_Initial;
	}
	public String getLyft_Period_current() {
		return Lyft_Period_current;
	}
	public void setLyft_Period_current(String lyft_Period_current) {
		Lyft_Period_current = lyft_Period_current;
	}
	public String getLyft_Date_Initial() {
		return Lyft_Date_Initial;
	}
	public void setLyft_Date_Initial(String lyft_Date_Initial) {
		Lyft_Date_Initial = lyft_Date_Initial;
	}
	public String getLyft_Date_Current() {
		return Lyft_Date_Current;
	}
	public void setLyft_Date_Current(String lyft_Date_Current) {
		Lyft_Date_Current = lyft_Date_Current;
	}
	public String getLocation_Mnemonic() {
		return Location_Mnemonic;
	}
	public void setLocation_Mnemonic(String location_Mnemonic) {
		Location_Mnemonic = location_Mnemonic;
	}
	public String getRide_hailing_id() {
		return Ride_hailing_id;
	}
	public void setRide_hailing_id(String ride_hailing_id) {
		Ride_hailing_id = ride_hailing_id;
	}
	 
	 
	 
	 
	 
	 
	 

	
	
}
