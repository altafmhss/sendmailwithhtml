import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;


public class Mainssd {

    public static void main(String[] args) throws IOException {        
        try {
        	vo v=new vo();
            File f = new File("/D:/text/out1.txt");
            
            File fout = new File("/D:/text/data1.txt");
        	FileOutputStream fos = new FileOutputStream(fout);
         
        	BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
            long count =0;
            Scanner sc = new Scanner(f);
            	writes wt=new writes();
            String[] details = new String[400]; //declare with size
            //String line = sc.nextLine();
            //List<Person> people = new ArrayList<Person>();
            while(sc.hasNextLine()){
            	count++;
            	if(count==10000)
            	{
            		System.out.println("10000 rows read");
            	}
            		
            	if(count==50000)
            	{
            		System.out.println("50000 rows read");
            	}
            		
            	
            	
            	if(count==100000)
            	{
            		System.out.println("100000 rows read");
            	}
            		
            	
            	if(count==200000)
            	{
            		System.out.println("200000 rows read");
            	}
            		
            	
            	if(count==500000)
            	{
            		System.out.println("500000 rows read");
            	}
            		
            	
            	if(count==1000000)
            	{
            		System.out.println("1000000 rows read");
            	}
            		
            	
                 String line = sc.nextLine();
                 line = sc.nextLine();
                 details = line.split("\\|",-1);
                 if(details.length==134)
                 {
                	
                    
                    	 
                     //System.out.println(details[133]);
                     //System.out.println(details[details.length-1]);
                    /* List<String> wordList = Arrays.asList(details);  

                     System.out.println(wordList.get(123)); */
                     
                     
                     v.setBRAND(details[0]);
                     v.setASSIGNED_BRAND(details[1]);
                     v.setCO_LOC_NAME(details[2]);
                     v.setCO_LOC_DBR10(details[3]);
                     v.setCO_LOC_DBR(details[4]);
                     v.setCO_RENTAL_STATE(details[5]);
                     v.setACCIDENT_STATE(details[6]);
                     v.setRENTER_STATE(details[7]);
                     v.setCOMPANY_CODE(details[8]);
                     v.setCI_LOCATION_NAME(details[9]);
                     v.setCO_DISTRICT(details[10]);
                     v.setCO_ZONE(details[11]);
                     v.setCI_DISTRICT(details[12]);
                     v.setCI_ZONE(details[13]);
                     v.setFLEET_OWNER(details[14]);
                     v.setVEH_MAKE(details[15]);
                     v.setVEH_MODEL(details[16]);
                     v.setMVA(details[17]);
                     v.setVIN(details[18]);
                     v.setESTIMATE_ID(details[19]);
                     v.setRA_NUMBER(details[20]);
                     v.setCLAIM_NUMBER(details[21]);
                     v.setRENTER_NAME_FULL(details[22]);
                     v.setREVIEWED_YN(details[23]);
                     v.setDOB(details[24]);
                     v.setRECOVERY_STATUS(details[25]);
                     v.setRECOVERY_CLOSE_CODE(details[26]);
                     v.setRENTAL_DATE(details[27]);
                     v.setSYSTEM_ENTRY_DATE(details[28]);
                     v.setDATE_OF_LOSS(details[29]);
                     v.setREPORT_DATE(details[30]);
                     v.setREPORT_MOYR(details[31]);
                     v.setLOSS_TYPE(details[32]);
                     v.setSED_RUC(details[33]);
                     v.setTCOR_TOTAL(details[34]);
                     v.setEST_TOTAL(details[35]);
                     v.setEST_DIMVAL(details[36]);
                     v.setEST_LOU(details[37]);
                     v.setEST_STORAGE_TOW(details[38]);
                     v.setEST_ADMIN(details[39]);
                     v.setREVIEW_DATE(details[40]);
                     v.setMAX_BILLED_TOTAL(details[41]);
                     v.setMAX_BILLED_SED_TOTAL(details[42]);
                     v.setCONVERT_BILLED_AMT(details[43]);
                     v.setCONVERT_OPEN_MAXBILLED(details[44]);
                     v.setCONVERT_CLOSED_MAXBILLED(details[45]);
                     v.setVIK_BILLED_AMT(details[46]);
                     v.setVIK_REBILLING(details[47]);
                     v.setSEDWICK_BILLED_TOTAL(details[48]);
                     v.setVIKING_BILLED_TOTAL(details[49]);
                     v.setDAMAGE_AMOUNT(details[50]);
                     v.setLOSS_OF_USE_AMOUNT(details[51]);
                     v.setADMIN_FEE_AMOUNT(details[52]);
                     v.setDIMVAL_AMOUNT(details[53]);
                     v.setSTORAGE_TOW_AMOUNT(details[54]);
                     v.setRECOVERED_AMT_GROSS(details[55]);
                     v.setPAYMENTS(details[56]);
                     v.setRECOVERED_AMT_ADJUSTED(details[57]);
                     v.setNON_CASH_SUBRO_RECOVERY(details[58]);
                     v.setVIK_RECOVERY_TOTAL(details[59]);
                     v.setVIK_COLLECTION_RECOVERY(details[60]);
                     v.setVIK_BILLING_RECOVERY(details[61]);
                     v.setCONVERT_RECOVERED_AMT(details[62]);
                     v.setCONVERT_CLOSED_RECOVERY(details[63]);
                     v.setCONVERT_PENDING_RECOVERY(details[64]);
                     v.setWRITEOFF_TOTAL(details[65]);
                     v.setCONVERT_WRITEOFF_TOTAL(details[66]);
                     v.setOUTSTANDING_TOTAL(details[67]);
                     v.setCOMMISSION_COSTS(details[68]);
                     v.setBILLING_COMMISSION(details[69]);
                     v.setCOLLECTION_COMMISSION(details[70]);
                     v.setCREDIT_CARD_COST(details[71]);
                     v.setVIK_COMMISION(details[72]);
                     v.setCOMMISSION_REIMBURSEMENT(details[73]);
                     v.setCONVERT_COMMISSION_COST(details[74]);
                     v.setOTHER_COLLECTION_COST(details[75]);
                     v.setCONVERT_OTHER_COLLECT_COST(details[76]);
                     v.setCURRENT_BILLINGS(details[77]);
                     v.setPRIOR_TO_MAY_ADJ(details[78]);
                     v.setESV_ADJUSTMENT_AMT(details[79]);
                     v.setOTHER_REDUCTIONS(details[80]);
                     v.setBILLED_DATE(details[81]);
                     v.setBILLED_MOYR(details[82]);
                     v.setESUB_IND(details[83]);
                     v.setESUB_DATE(details[84]);
                     v.setNEGOTIATED_AMT(details[85]);
                     v.setNEGOTIATED_DATE(details[86]);
                     v.setNEGOTIATED_MOYR(details[87]);
                     v.setRECOVERED_AMT_NET(details[88]);
                     v.setDAMAGE_AMOUNT_COLLECTED(details[89]);
                     v.setLOU_COLLECTED(details[90]);
                     v.setADMIN_COLLECTED(details[91]);
                     v.setDIMVAL_COLLECTED(details[92]);
                     v.setSTORAGE_TOW_COLLECTED(details[93]);
                     v.setRECOVERY_EXPENSE_WCOM(details[94]);
                     v.setRECOVERED_IND(details[95]);
                     v.setFIRST_RECOVERY_DATE(details[96]);
                     v.setLAST_RECOVERY_DATE(details[97]);
                     v.setLAST_RECOVERY_MOYR(details[98]);
                     v.setINSTALLMENT_IND(details[99]);
                     v.setDUPLICATE_TYPE(details[100]);
                     v.setUNALLOCATED_IND(details[101]);
                     v.setLDW_CDW_IND(details[102]);
                     v.setCORPORATE_COVERAGE(details[103]);
                     v.setFREE_CDW_IND(details[104]);
                     v.setCDW_WITH_DEDUCTIBLE_IND(details[105]);
                     v.setCDW_DEDUCTIBLE_AMT(details[106]);
                     v.setAWDBCD_PARENT_NAME(details[107]);
                     v.setAWDBCD_DIV_NAME(details[108]);
                     v.setAWDBCD_PARENT(details[109]);
                     v.setAWDBCD_DIV(details[110]);
                     v.setRECOVERY_REP_NAME(details[111]);
                     v.setAGENCY_ATTORNEY(details[112]);
                     v.setASSIGNED_IND(details[113]);
                     v.setZIP_RECOVERY_LETTER(details[114]);
                     v.setLIABILITY_IND(details[115]);
                     v.setVIK_IND(details[116]);
                     v.setLAST_LETTER_NAME(details[117]);
                     v.setLAST_LETTER_DATE(details[118]);
                     v.setDAYS_TO_BILL(details[119]);
                     v.setZIP_MEMBER_ID(details[120]);
                     v.setZIP_FLEET_ID(details[121]);
                     v.setRECOVERY_CLOSE_DATE(details[122]);
                     v.setZIP_NUMBER(details[123]);
                     v.setRUN_DATE(details[124]);
                     v.setLOSS_CAUSATION(details[125]);
                     v.setSENT_DATE(details[126]);
                     v.setRECOVERY_STATUS_DESC(details[127]);
                     v.setLyft_Period_Initial(details[128]);
                     v.setLyft_Period_current(details[129]);
                     v.setLyft_Date_Initial(details[130]);
                     v.setLyft_Date_Current(details[131]);
                     v.setLocation_Mnemonic(details[132]);
                     v.setRide_hailing_id(details[133]);
                     
                    
                     
                   /* for(int i=0; i<details.length;i++)
                    {
                    	System.out.println(v.getBRAND());
                    	
                    	//bw.write(details[i]);
            			//bw.newLine();
                    }*/
                    //String gender = details[0];
                    //String name = details[1];
                    /*int age = Integer.parseInt(details[2]);
                    Person p = new Person(gender, name, age);
                    people.add(p);*/
                    
                 
                     
                    bw.write(v.getBRAND());
                    bw.write("|");
                    bw.write(v.getASSIGNED_BRAND());
                    bw.write("|");
                    bw.write(v.getCO_LOC_NAME());
                    bw.write("|");
                    bw.write(v.getCO_LOC_DBR10());
                    bw.write("|");
                    bw.write(v.getCO_LOC_DBR());
                    bw.write("|");
                    bw.write(v.getCO_RENTAL_STATE());
                    bw.write("|");
                    bw.write(v.getACCIDENT_STATE());
                    bw.write("|");
                    bw.write(v.getRENTER_STATE());
                    bw.write("|");
                    bw.write(v.getCOMPANY_CODE());
                    bw.write("|");
                    bw.write(v.getCI_LOCATION_NAME());
                    bw.write("|");
                    bw.write(v.getCO_DISTRICT());
                    bw.write("|");
                    bw.write(v.getCO_ZONE());
                    bw.write("|");
                    bw.write(v.getCI_DISTRICT());
                    bw.write("|");
                    bw.write(v.getCI_ZONE());
                    bw.write("|");
                    bw.write(v.getFLEET_OWNER());
                    bw.write("|");
                    bw.write(v.getVEH_MAKE());
                    bw.write("|");
                    bw.write(v.getVEH_MODEL());
                    bw.write("|");
                    bw.write(v.getMVA());
                    bw.write("|");
                    bw.write(v.getVIN());
                    bw.write("|");
                    bw.write(v.getESTIMATE_ID());
                    bw.write("|");
                    bw.write(v.getRA_NUMBER());
                    bw.write("|");
                    bw.write(v.getCLAIM_NUMBER());
                    bw.write("|");
                    bw.write(v.getRENTER_NAME_FULL());
                    bw.write("|");
                    bw.write(v.getREVIEWED_YN());
                    bw.write("|");
                    bw.write(v.getDOB());
                    bw.write("|");
                    bw.write(v.getRECOVERY_STATUS());
                    bw.write("|");
                    bw.write(v.getRECOVERY_CLOSE_CODE());
                    bw.write("|");
                    bw.write(v.getRENTAL_DATE());
                    bw.write("|");
                    bw.write(v.getSYSTEM_ENTRY_DATE());
                    bw.write("|");
                    bw.write(v.getDATE_OF_LOSS());
                    bw.write("|");
                    bw.write(v.getREPORT_DATE());
                    bw.write("|");
                    bw.write(v.getREPORT_MOYR());
                    bw.write("|");
                    bw.write(v.getLOSS_TYPE());
                    bw.write("|");
                    bw.write(v.getSED_RUC());
                    bw.write("|");
                    bw.write(v.getTCOR_TOTAL());
                    bw.write("|");
                    bw.write(v.getEST_TOTAL());
                    bw.write("|");
                    bw.write(v.getEST_DIMVAL());
                    bw.write("|");
                    bw.write(v.getEST_LOU());
                    bw.write("|");
                    bw.write(v.getEST_STORAGE_TOW());
                    bw.write("|");
                    bw.write(v.getEST_ADMIN());
                    bw.write("|");
                    bw.write(v.getREVIEW_DATE());
                    bw.write("|");
                    bw.write(v.getMAX_BILLED_TOTAL());
                    bw.write("|");
                    bw.write(v.getMAX_BILLED_SED_TOTAL());
                    bw.write("|");
                    bw.write(v.getCONVERT_BILLED_AMT());
                    bw.write("|");
                    bw.write(v.getCONVERT_OPEN_MAXBILLED());
                    bw.write("|");
                    bw.write(v.getCONVERT_CLOSED_MAXBILLED());
                    bw.write("|");
                    bw.write(v.getVIK_BILLED_AMT());
                    bw.write("|");
                    bw.write(v.getVIK_REBILLING());
                    bw.write("|");
                    bw.write(v.getSEDWICK_BILLED_TOTAL());
                    bw.write("|");
                    bw.write(v.getVIKING_BILLED_TOTAL());
                    bw.write("|");
                    bw.write(v.getDAMAGE_AMOUNT());
                    bw.write("|");
                    bw.write(v.getLOSS_OF_USE_AMOUNT());
                    bw.write("|");
                    bw.write(v.getADMIN_FEE_AMOUNT());
                    bw.write("|");
                    bw.write(v.getDIMVAL_AMOUNT());
                    bw.write("|");
                    bw.write(v.getSTORAGE_TOW_AMOUNT());
                    bw.write("|");
                    bw.write(v.getRECOVERED_AMT_GROSS());
                    bw.write("|");
                    bw.write(v.getPAYMENTS());
                    bw.write("|");
                    bw.write(v.getRECOVERED_AMT_ADJUSTED());
                    bw.write("|");
                    bw.write(v.getNON_CASH_SUBRO_RECOVERY());
                    bw.write("|");
                    bw.write(v.getVIK_RECOVERY_TOTAL());
                    bw.write("|");
                    bw.write(v.getVIK_COLLECTION_RECOVERY());
                    bw.write("|");
                    bw.write(v.getVIK_BILLING_RECOVERY());
                    bw.write("|");
                    bw.write(v.getCONVERT_RECOVERED_AMT());
                    bw.write("|");
                    bw.write(v.getCONVERT_CLOSED_RECOVERY());
                    bw.write("|");
                    bw.write(v.getCONVERT_PENDING_RECOVERY());
                    bw.write("|");
                    bw.write(v.getWRITEOFF_TOTAL());
                    bw.write("|");
                    bw.write(v.getCONVERT_WRITEOFF_TOTAL());
                    bw.write("|");
                    bw.write(v.getOUTSTANDING_TOTAL());
                    bw.write("|");
                    bw.write(v.getCOMMISSION_COSTS());
                    bw.write("|");
                    bw.write(v.getBILLING_COMMISSION());
                    bw.write("|");
                    bw.write(v.getCOLLECTION_COMMISSION());
                    bw.write("|");
                    bw.write(v.getCREDIT_CARD_COST());
                    bw.write("|");
                    bw.write(v.getVIK_COMMISION());
                    bw.write("|");
                    bw.write(v.getCOMMISSION_REIMBURSEMENT());
                    bw.write("|");
                    bw.write(v.getCONVERT_COMMISSION_COST());
                    bw.write("|");
                    bw.write(v.getOTHER_COLLECTION_COST());
                    bw.write("|");
                    bw.write(v.getCONVERT_OTHER_COLLECT_COST());
                    bw.write("|");
                    bw.write(v.getCURRENT_BILLINGS());
                    bw.write("|");
                    bw.write(v.getPRIOR_TO_MAY_ADJ());
                    bw.write("|");
                    bw.write(v.getESV_ADJUSTMENT_AMT());
                    bw.write("|");
                    bw.write(v.getOTHER_REDUCTIONS());
                    bw.write("|");
                    bw.write(v.getBILLED_DATE());
                    bw.write("|");
                    bw.write(v.getBILLED_MOYR());
                    bw.write("|");
                    bw.write(v.getESUB_IND());
                    bw.write("|");
                    bw.write(v.getESUB_DATE());
                    bw.write("|");
                    bw.write(v.getNEGOTIATED_AMT());
                    bw.write("|");
                    bw.write(v.getNEGOTIATED_DATE());
                    bw.write("|");
                    bw.write(v.getNEGOTIATED_MOYR());
                    bw.write("|");
                    bw.write(v.getRECOVERED_AMT_NET());
                    bw.write("|");
                    bw.write(v.getDAMAGE_AMOUNT_COLLECTED());
                    bw.write("|");
                    bw.write(v.getLOU_COLLECTED());
                    bw.write("|");
                    bw.write(v.getADMIN_COLLECTED());
                    bw.write("|");
                    bw.write(v.getDIMVAL_COLLECTED());
                    bw.write("|");
                    bw.write(v.getSTORAGE_TOW_COLLECTED());
                    bw.write("|");
                    bw.write(v.getRECOVERY_EXPENSE_WCOM());
                    bw.write("|");
                    bw.write(v.getRECOVERED_IND());
                    bw.write("|");
                    bw.write(v.getFIRST_RECOVERY_DATE());
                    bw.write("|");
                    bw.write(v.getLAST_RECOVERY_DATE());
                    bw.write("|");
                    bw.write(v.getLAST_RECOVERY_MOYR());
                    bw.write("|");
                    bw.write(v.getINSTALLMENT_IND());
                    bw.write("|");
                    bw.write(v.getDUPLICATE_TYPE());
                    bw.write("|");
                    bw.write(v.getUNALLOCATED_IND());
                    bw.write("|");
                    bw.write(v.getLDW_CDW_IND());
                    bw.write("|");
                    bw.write(v.getCORPORATE_COVERAGE());
                    bw.write("|");
                    bw.write(v.getFREE_CDW_IND());
                    bw.write("|");
                    bw.write(v.getCDW_WITH_DEDUCTIBLE_IND());
                    bw.write("|");
                    bw.write(v.getCDW_DEDUCTIBLE_AMT());
                    bw.write("|");
                    bw.write(v.getAWDBCD_PARENT_NAME());
                    bw.write("|");
                    bw.write(v.getAWDBCD_DIV_NAME());
                    bw.write("|");
                    bw.write(v.getAWDBCD_PARENT());
                    bw.write("|");
                    bw.write(v.getAWDBCD_DIV());
                    bw.write("|");
                    bw.write(v.getRECOVERY_REP_NAME());
                    bw.write("|");
                    bw.write(v.getAGENCY_ATTORNEY());
                    bw.write("|");
                    bw.write(v.getASSIGNED_IND());
                    bw.write("|");
                    bw.write(v.getZIP_RECOVERY_LETTER());
                    bw.write("|");
                    bw.write(v.getLIABILITY_IND());
                    bw.write("|");
                    bw.write(v.getVIK_IND());
                    bw.write("|");
                    bw.write(v.getLAST_LETTER_NAME());
                    bw.write("|");
                    bw.write(v.getLAST_LETTER_DATE());
                    bw.write("|");
                    bw.write(v.getDAYS_TO_BILL());
                    bw.write("|");
                    bw.write(v.getZIP_MEMBER_ID());
                    bw.write("|");
                    bw.write(v.getZIP_FLEET_ID());
                    bw.write("|");
                    bw.write(v.getRECOVERY_CLOSE_DATE());
                    bw.write("|");
                    bw.write(v.getZIP_NUMBER());
                    bw.write("|");
                    bw.write(v.getRUN_DATE());
                    bw.write("|");
                    bw.write(v.getLOSS_CAUSATION());
                    bw.write("|");
                    bw.write(v.getSENT_DATE());
                    bw.write("|");
                    bw.write(v.getRECOVERY_STATUS_DESC());
                    bw.write("|");
                    bw.write(v.getLyft_Period_Initial());
                    bw.write("|");
                    bw.write(v.getLyft_Period_current());
                    bw.write("|");
                    bw.write(v.getLyft_Date_Initial());
                    bw.write("|");
                    bw.write(v.getLyft_Date_Current());
                    bw.write("|");
                    bw.write(v.getLocation_Mnemonic());
                    bw.write("|");
                    bw.write(v.getRide_hailing_id());
                    
                    
                    bw.newLine();

                 }
                 
                 else
                 {
                	 line = sc.nextLine();
                 }
                
                
                
                
                
                
                
            }

            /*for(Person p: people){
                System.out.println(p.toString());
            }*/
            
            
            
            
            
            
            
            
            
            sc.close();
            bw.close();
        } catch (FileNotFoundException e) {         
            e.printStackTrace();
        }
        
    }


/*class Person{

    private String gender;
    private String name;
    private int age;

    public Person(String gender, String name, int age){
        this.gender = gender;
        this.setName(name);
        this.age = age;
    }

    *//**
     * @return the gender
     *//*
public String getGender() {
    return gender;
}

*//**
 * @param gender the gender to set
 *//*
public void setGender(String gender) {
    this.gender = gender;
}

*//**
 * @param name the name to set
 *//*
public void setName(String name) {
    this.name = name;
}

*//**
 * @return the name
 *//*
public String getName() {
    return name;
}

*//**
 * @return the age
 *//*
public int getAge() {
    return age;
}

*//**
 * @param age the age to set
 *//*
public void setAge(int age) {
    this.age = age;
}

public String toString(){
    return this.gender + " " + this.name + " " + this.age;
}
*/





}